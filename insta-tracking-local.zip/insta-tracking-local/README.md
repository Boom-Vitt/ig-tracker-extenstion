# Instagram Follower Tracker

A Chrome / Edge / Brave extension (Manifest V3) that:

- **Auto-syncs your followers + following** on a schedule (off / 6h / 12h / 24h / 3d / 7d).
- **Detects unfollowers, new followers, ghosts, and fans** between snapshots.
- **Exports any list to CSV** with one click.
- **Notifies you** when somebody unfollows.
- **Persists in a sidebar** instead of a fragile popup.

No accounts, no third-party servers, no passwords. The extension only runs on `instagram.com` tabs, only uses your existing logged-in session, and only stores data inside your own browser (`chrome.storage.local`) and downloaded files.

---

## Install (unpacked)

1. Open `chrome://extensions` (or `edge://extensions`).
2. Toggle **Developer mode** on (top-right).
3. Click **Load unpacked**.
4. Select this folder: `/Users/boomvitt/Desktop/insta-tracking-local`.
5. Pin the extension to your toolbar.

## Use

1. Open https://www.instagram.com and log in.
2. Click the extension icon — the **side panel** opens (and stays open while you browse).
3. Click **Sync Now & Save Snapshot** for the first baseline.
4. Optional: pick an **Auto-sync** interval. Auto-sync runs while at least one Instagram tab is open.

### Tabs in the sidebar

| Tab | Meaning |
|---|---|
| Unfollowers | People who used to follow you but don't anymore. |
| New | People who started following you since the last baseline. |
| Ghosts | Accounts you follow that don't follow you back. |
| Fans | Accounts that follow you but you don't follow back. |
| History | Full event log of follow/unfollow changes across all syncs. |

Each tab has its own **Export CSV** button.

## Files

- `manifest.json` — extension manifest (MV3).
- `sidepanel.html` / `sidepanel.css` / `sidepanel.js` — the sidebar UI.
- `content.js` — runs on `instagram.com`, calls Instagram's internal web API with your existing session cookies. Exponential backoff on 429s. Resumable: if a scrape is interrupted, the next run picks up where it left off.
- `background.js` — service worker. Owns the `chrome.alarms` schedule, drives auto-syncs, writes diffs, and fires `chrome.notifications` on unfollows.
- `icons/` — extension icons.

## Storage schema (v2)

```
{
  schemaVersion: 2,
  account: { username, userId },
  baseline: { ts, followers: [...], following: [...] }, // current rolling state
  events: [ { ts, kind, user } ],                       // diff log, capped 5000
  settings: { autoSyncHours, autoDownload, notifyUnfollow }
}
```

Each sync replaces `baseline` and appends diff events to `events`. v1 `snapshots` arrays are auto-migrated on first run (latest snapshot becomes the baseline).

## Notes & limits

- Auto-sync can only run while an Instagram tab is open in some Chrome window. If no tab is open when the alarm fires, the run is skipped and reported in the side panel.
- Instagram may rate-limit aggressive scraping. The extension paces requests at ~1 page (50 users) per second with jitter and backs off exponentially on 429/503.
- The internal endpoints (`/api/v1/friendships/<id>/{followers|following}/`, `/api/v1/users/web_profile_info/`) are the same ones the Instagram web client itself calls. If Instagram changes them, the extension will need to be updated.
- Personal use only. Respect [Instagram's Terms of Service](https://help.instagram.com/581066165581870) and the privacy of the people in your lists.
