// background.js — service worker.
// Responsibilities:
//   1. Configure the toolbar action to open the side panel.
//   2. Maintain a chrome.alarms-driven auto-sync schedule.
//   3. On alarm fire: locate an Instagram tab, drive content.js to scrape
//      followers + following, commit the diff to storage, optionally
//      auto-download a snapshot, and notify on lost followers.

const ALARM_NAME = "autoSync";
const DEFAULT_SETTINGS = {
  autoSyncHours: 0,
  autoDownload: false,
  notifyUnfollow: true,
};

// --- side panel wiring ----------------------------------------------------

// Run on every service-worker startup (not just install) so reloading the
// unpacked extension during development still wires the icon → side panel.
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch(() => {});

chrome.runtime.onInstalled.addListener(async () => {
  // Seed storage with defaults if missing, and migrate v1 snapshots.
  const r = await chrome.storage.local.get([
    "schemaVersion",
    "settings",
    "events",
    "baseline",
    "snapshots",
  ]);
  const patch = {};
  if (!r.settings) patch.settings = { ...DEFAULT_SETTINGS };
  if (!Array.isArray(r.events)) patch.events = [];
  if (r.schemaVersion !== 2) {
    patch.schemaVersion = 2;
    if (!r.baseline && Array.isArray(r.snapshots) && r.snapshots.length) {
      const latest = r.snapshots[r.snapshots.length - 1];
      patch.baseline = {
        ts: latest.ts,
        followers: latest.followers || [],
        following: latest.following || [],
      };
      patch.account = { username: latest.username, userId: null };
    }
  }
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
  if (r.snapshots) await chrome.storage.local.remove("snapshots");

  await rescheduleAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  rescheduleAlarm().catch(() => {});
});

// --- alarm scheduling -----------------------------------------------------

async function getSettings() {
  const r = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...(r.settings || {}) };
}

async function rescheduleAlarm() {
  const s = await getSettings();
  await chrome.alarms.clear(ALARM_NAME);
  const hours = Number(s.autoSyncHours) || 0;
  if (hours > 0) {
    await chrome.alarms.create(ALARM_NAME, {
      periodInMinutes: hours * 60,
      delayInMinutes: Math.min(5, hours * 60), // first fire shortly after configuration
    });
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    runAutoSync().catch((e) => console.error("[follower-tracker] auto-sync error", e));
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "RESCHEDULE_ALARM") {
    rescheduleAlarm().then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === "RUN_AUTOSYNC_NOW") {
    runAutoSync().then((r) => sendResponse(r)).catch((e) =>
      sendResponse({ ok: false, error: e?.message || String(e) })
    );
    return true;
  }
});

// --- scrape via content script port --------------------------------------

async function findInstagramTab() {
  const tabs = await chrome.tabs.query({ url: "https://www.instagram.com/*" });
  if (tabs.length === 0) return null;
  // Prefer non-discarded, non-loading tabs.
  const usable = tabs.find((t) => !t.discarded && t.status !== "unloaded");
  return usable || tabs[0];
}

function scrapeViaTab(tabId, kind) {
  return new Promise((resolve, reject) => {
    let port;
    try {
      port = chrome.tabs.connect(tabId, { name: "scrape" });
    } catch (e) {
      reject(e);
      return;
    }
    let done = false;
    port.onMessage.addListener((msg) => {
      if (msg.type === "DONE") {
        done = true;
        try { port.disconnect(); } catch (_) {}
        resolve(msg);
      } else if (msg.type === "ERROR") {
        try { port.disconnect(); } catch (_) {}
        reject(new Error(msg.error || "scrape failed"));
      }
      // PROGRESS messages are ignored in the background.
    });
    port.onDisconnect.addListener(() => {
      if (!done) reject(new Error("Port disconnected before completion"));
    });
    port.postMessage({ type: "SCRAPE", kind });
  });
}

// --- diff + commit (duplicated minimally from sidepanel.js; the side panel
// won't necessarily be open when auto-sync fires) ---------------------------

function indexUsers(list) {
  // Index by both pk (immutable) and username so the diff can match across
  // renames. Username-only matches are accepted as a fallback when one or
  // both entries lack a pk (e.g. baselines scraped before pk capture).
  const byPk = new Map();
  const byName = new Map();
  for (const u of list || []) {
    const pk = u.pk != null ? String(u.pk) : null;
    if (pk) byPk.set(pk, u);
    const name = (u.username || "").toLowerCase();
    if (name) byName.set(name, u);
  }
  return { byPk, byName };
}
function isSamePerson(u, otherIdx) {
  const pk = u.pk != null ? String(u.pk) : null;
  if (pk && otherIdx.byPk.has(pk)) return true;
  const name = (u.username || "").toLowerCase();
  if (!name) return false;
  const candidate = otherIdx.byName.get(name);
  if (!candidate) return false;
  const candidatePk = candidate.pk != null ? String(candidate.pk) : null;
  if (pk && candidatePk && pk !== candidatePk) return false;
  return true;
}
function diffUsers(prev, next) {
  const prevIdx = indexUsers(prev);
  const nextIdx = indexUsers(next);
  const added = [];
  const removed = [];
  for (const u of next || []) if (!isSamePerson(u, prevIdx)) added.push(u);
  for (const u of prev || []) if (!isSamePerson(u, nextIdx)) removed.push(u);
  return { added, removed };
}

async function commitSnapshot({ username, userId, followers, following }) {
  const store = await chrome.storage.local.get(["baseline", "events", "account"]);
  const baseline = store.baseline;
  const events = Array.isArray(store.events) ? store.events.slice() : [];

  let followerDiff = { added: [], removed: [] };
  let followingDiff = { added: [], removed: [] };
  if (baseline && baseline.followers && baseline.following) {
    followerDiff = diffUsers(baseline.followers, followers);
    followingDiff = diffUsers(baseline.following, following);
  }

  const ts = Date.now();
  const slim = (u) => ({ username: u.username, full_name: u.full_name, pk: u.pk });
  for (const u of followerDiff.added) events.push({ ts, kind: "follower_gained", user: slim(u) });
  for (const u of followerDiff.removed) events.push({ ts, kind: "follower_lost", user: slim(u) });
  for (const u of followingDiff.added) events.push({ ts, kind: "started_following", user: slim(u) });
  for (const u of followingDiff.removed) events.push({ ts, kind: "stopped_following", user: slim(u) });
  while (events.length > 5000) events.shift();

  await chrome.storage.local.set({
    schemaVersion: 2,
    account: { username, userId: userId || store.account?.userId || null },
    baseline: { ts, followers, following },
    events,
  });

  return { followerDiff, followingDiff, priorTs: baseline?.ts || null };
}

// --- auto-sync runner -----------------------------------------------------

async function runAutoSync() {
  // Cheap cross-context mutex: a manual "Sync Now" from the side panel and a
  // background alarm tick can otherwise race over the same resume key.
  const lock = await chrome.storage.local.get("_syncInFlight");
  if (lock._syncInFlight && Date.now() - lock._syncInFlight < 30 * 60 * 1000) {
    notifyTabs({ type: "AUTOSYNC_FAILED", reason: "Another sync is already running" });
    return { ok: false, reason: "in_flight" };
  }
  await chrome.storage.local.set({ _syncInFlight: Date.now() });

  const tab = await findInstagramTab();
  if (!tab) {
    await chrome.storage.local.remove("_syncInFlight");
    notifyTabs({ type: "AUTOSYNC_FAILED", reason: "No Instagram tab open" });
    return { ok: false, reason: "no_tab" };
  }
  try {
    // Confirm the page is logged in.
    const ping = await chrome.tabs.sendMessage(tab.id, { type: "PING" }).catch(() => null);
    if (!ping || !ping.username) {
      notifyTabs({ type: "AUTOSYNC_FAILED", reason: "Not signed in to Instagram" });
      return { ok: false, reason: "not_signed_in" };
    }

    const followers = await scrapeViaTab(tab.id, "followers");
    const following = await scrapeViaTab(tab.id, "following");
    const settings = await getSettings();
    const result = await commitSnapshot({
      username: followers.username,
      userId: followers.userId,
      followers: followers.users,
      following: following.users,
    });

    // Optional auto-download.
    if (settings.autoDownload) {
      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      const filename = `instagram_snapshot_${followers.username}_${stamp}.json`;
      const payload = {
        username: followers.username,
        ts: Date.now(),
        followers: followers.users,
        following: following.users,
      };
      const dataUrl = "data:application/json;charset=utf-8," +
        encodeURIComponent(JSON.stringify(payload, null, 2));
      try {
        await chrome.downloads.download({ url: dataUrl, filename, saveAs: false });
      } catch (e) {
        console.warn("[follower-tracker] auto-download failed", e);
      }
    }

    // Notify on unfollowers.
    const lost = result.followerDiff.removed;
    if (settings.notifyUnfollow && lost.length > 0 && result.priorTs) {
      const sample = lost.slice(0, 3).map((u) => "@" + u.username).join(", ");
      const more = lost.length > 3 ? ` and ${lost.length - 3} more` : "";
      try {
        await chrome.notifications.create(`unfollow_${Date.now()}`, {
          type: "basic",
          iconUrl: "icons/icon128.png",
          title: `${lost.length} unfollower${lost.length === 1 ? "" : "s"}`,
          message: `${sample}${more} unfollowed @${followers.username}.`,
          priority: 1,
        });
      } catch (e) {
        console.warn("[follower-tracker] notification failed", e);
      }
    }

    const summary = result.priorTs
      ? `+${result.followerDiff.added.length} / -${lost.length} followers`
      : `baseline saved (${followers.users.length} followers)`;
    notifyTabs({ type: "AUTOSYNC_DONE", summary });
    return { ok: true, summary };
  } catch (e) {
    const reason = e?.message || String(e);
    notifyTabs({ type: "AUTOSYNC_FAILED", reason });
    return { ok: false, reason };
  } finally {
    await chrome.storage.local.remove("_syncInFlight");
  }
}

// Best-effort broadcast to whichever side panel / popup is open.
function notifyTabs(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {});
}

// Clicking a notification opens the side panel (best-effort) and focuses
// the Instagram tab so the user can scroll/check.
chrome.notifications.onClicked.addListener(async (notificationId) => {
  try {
    const tab = await findInstagramTab();
    if (tab) {
      await chrome.tabs.update(tab.id, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
      try { await chrome.sidePanel.open({ windowId: tab.windowId }); } catch (_) {}
    }
  } catch (_) {}
  chrome.notifications.clear(notificationId);
});
