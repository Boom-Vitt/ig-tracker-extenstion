// sidepanel.js — primary UI. Reads the v2 store, drives scrapes via the
// content script port, and reacts to background-driven auto-sync results.

const $ = (id) => document.getElementById(id);

const statusDot = $("statusDot");
const statusText = $("statusText");
const lastSync = $("lastSync");

const followerCount = $("followerCount");
const followingCount = $("followingCount");
const followerDelta = $("followerDelta");
const followingDelta = $("followingDelta");

const btnSyncNow = $("btnSyncNow");
const btnFollowers = $("btnFollowers");
const btnFollowing = $("btnFollowing");
const btnOpenProfile = $("btnOpenProfile");

const autoSyncInterval = $("autoSyncInterval");
const autoDownload = $("autoDownload");
const notifyUnfollow = $("notifyUnfollow");

const progressSection = $("progressSection");
const progressFill = $("progressFill");
const progressText = $("progressText");

const pillUnfollowers = $("pillUnfollowers");
const pillNew = $("pillNew");
const pillGhosts = $("pillGhosts");
const pillFans = $("pillFans");

let currentTab = null;
let currentUsername = null;

const DEFAULT_SETTINGS = {
  autoSyncHours: 0,
  autoDownload: false,
  notifyUnfollow: true,
};

// --- helpers --------------------------------------------------------------

async function getActiveIgTab() {
  // Prefer the active tab if it's IG; otherwise any IG tab in the current window.
  let [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (active && isInstagram(active.url)) return active;
  const tabs = await chrome.tabs.query({ url: "https://www.instagram.com/*" });
  return tabs[0] || active || null;
}

function isInstagram(url) {
  return /^https?:\/\/(www\.)?instagram\.com\//.test(url || "");
}

function setStatus(kind, msg) {
  statusDot.className = "dot " + kind;
  statusText.textContent = msg;
}

function setBusy(busy, label) {
  [btnSyncNow, btnFollowers, btnFollowing].forEach((b) => {
    b.disabled = busy || !currentUsername;
  });
  if (busy) {
    progressSection.classList.remove("hidden");
    progressText.textContent = label || "Working…";
    progressFill.style.width = "5%";
  } else {
    progressSection.classList.add("hidden");
    progressFill.style.width = "0%";
  }
}

function setProgress(pct, msg) {
  progressFill.style.width = Math.min(100, Math.max(0, pct)) + "%";
  if (msg) progressText.textContent = msg;
}

function formatAgo(ts) {
  if (!ts) return "";
  const diff = Date.now() - ts;
  if (diff < 60_000) return "just now";
  if (diff < 3600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86400_000) return `${Math.floor(diff / 3600_000)}h ago`;
  const days = Math.floor(diff / 86400_000);
  return `${days}d ago`;
}

// --- storage --------------------------------------------------------------

async function readStore() {
  const r = await chrome.storage.local.get([
    "schemaVersion",
    "account",
    "baseline",
    "events",
    "settings",
    "snapshots", // legacy v1 — migrate if seen
  ]);
  return r;
}

async function migrateV1(store) {
  if (store.schemaVersion === 2) return store;
  // v1 had a `snapshots` array. Take the latest as the baseline.
  const latest = Array.isArray(store.snapshots) && store.snapshots.length
    ? store.snapshots[store.snapshots.length - 1]
    : null;
  const next = {
    schemaVersion: 2,
    account: latest ? { username: latest.username, userId: null } : null,
    baseline: latest
      ? { ts: latest.ts, followers: latest.followers || [], following: latest.following || [] }
      : null,
    events: [],
    settings: { ...DEFAULT_SETTINGS, ...(store.settings || {}) },
  };
  await chrome.storage.local.set(next);
  await chrome.storage.local.remove("snapshots");
  return next;
}

async function getSettings() {
  const r = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...(r.settings || {}) };
}

async function saveSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await chrome.storage.local.set({ settings: next });
  return next;
}

// --- diff + commit --------------------------------------------------------

function indexByUsername(list) {
  const m = new Map();
  for (const u of list || []) m.set(u.username.toLowerCase(), u);
  return m;
}

function indexUsers(list) {
  const byPk = new Map();
  const byName = new Map();
  for (const u of list || []) {
    const pk = u.pk != null ? String(u.pk) : null;
    if (pk) byPk.set(pk, u);
    const name = (u.username || "").toLowerCase();
    if (name) byName.set(name, u);
  }
  return { byPk, byName };
}

// True when `u` corresponds to the same Instagram account as some entry in
// `otherIdx`. Matches by pk first (immutable). Falls back to username only
// when one or both sides lack a pk — so a rename keeps the link, but a
// username being reused by a different account (different pk) does not.
function isSamePerson(u, otherIdx) {
  const pk = u.pk != null ? String(u.pk) : null;
  if (pk && otherIdx.byPk.has(pk)) return true;
  const name = (u.username || "").toLowerCase();
  if (!name) return false;
  const candidate = otherIdx.byName.get(name);
  if (!candidate) return false;
  const candidatePk = candidate.pk != null ? String(candidate.pk) : null;
  if (pk && candidatePk && pk !== candidatePk) return false;
  return true;
}

function diffUsers(prev, next) {
  const prevIdx = indexUsers(prev);
  const nextIdx = indexUsers(next);
  const added = [];
  const removed = [];
  for (const u of next || []) if (!isSamePerson(u, prevIdx)) added.push(u);
  for (const u of prev || []) if (!isSamePerson(u, nextIdx)) removed.push(u);
  return { added, removed };
}

// Commit a fresh full scrape (followers + following) to the store: compute
// events vs current baseline, replace baseline, append events. Returns the
// computed deltas so the caller can notify / show toasts.
async function commitSnapshot({ username, userId, followers, following }) {
  const store = await readStore();
  const baseline = store.baseline;
  const events = Array.isArray(store.events) ? store.events.slice() : [];

  let followerDiff = { added: [], removed: [] };
  let followingDiff = { added: [], removed: [] };
  if (baseline && baseline.followers && baseline.following) {
    followerDiff = diffUsers(baseline.followers, followers);
    followingDiff = diffUsers(baseline.following, following);
  }

  const ts = Date.now();
  const slim = (u) => ({ username: u.username, full_name: u.full_name, pk: u.pk });
  for (const u of followerDiff.added) events.push({ ts, kind: "follower_gained", user: slim(u) });
  for (const u of followerDiff.removed) events.push({ ts, kind: "follower_lost", user: slim(u) });
  for (const u of followingDiff.added) events.push({ ts, kind: "started_following", user: slim(u) });
  for (const u of followingDiff.removed) events.push({ ts, kind: "stopped_following", user: slim(u) });

  // Cap events at 5000 (rolling).
  while (events.length > 5000) events.shift();

  const nextStore = {
    schemaVersion: 2,
    account: { username, userId: userId || store.account?.userId || null },
    baseline: { ts, followers, following },
    events,
  };
  await chrome.storage.local.set(nextStore);

  return {
    followers,
    following,
    followerDiff,
    followingDiff,
    priorTs: baseline?.ts || null,
  };
}

// --- scrape orchestration -------------------------------------------------

async function refreshStatus() {
  currentTab = await getActiveIgTab();
  if (!currentTab || !isInstagram(currentTab.url)) {
    setStatus("warn", "Open Instagram in a tab to start.");
    currentUsername = null;
    [btnSyncNow, btnFollowers, btnFollowing].forEach((b) => (b.disabled = true));
    return;
  }
  try {
    const res = await chrome.tabs.sendMessage(currentTab.id, { type: "PING" });
    if (res && res.username) {
      currentUsername = res.username;
      setStatus("ok", `Signed in as @${res.username}`);
      [btnSyncNow, btnFollowers, btnFollowing].forEach((b) => (b.disabled = false));
    } else {
      currentUsername = null;
      setStatus("warn", "Log in to Instagram to continue.");
    }
  } catch (e) {
    setStatus("warn", "Reload the Instagram tab to enable.");
  }
}

function runExportOnTab(tabId, kind) {
  return new Promise((resolve, reject) => {
    const port = chrome.tabs.connect(tabId, { name: "scrape" });
    let result = null;
    port.onMessage.addListener((msg) => {
      if (msg.type === "PROGRESS") {
        setProgress(msg.pct, msg.text);
      } else if (msg.type === "DONE") {
        result = msg;
        port.disconnect();
        resolve(msg);
      } else if (msg.type === "ERROR") {
        port.disconnect();
        reject(new Error(msg.error || "Unknown error"));
      }
    });
    port.onDisconnect.addListener(() => {
      if (!result) reject(new Error("Disconnected before completion"));
    });
    port.postMessage({ type: "SCRAPE", kind });
  });
}

// --- downloads ------------------------------------------------------------

function csvForUsers(rows) {
  const header = "username,full_name,profile_url,is_verified,is_private\n";
  const esc = (s) => `"${String(s ?? "").replace(/"/g, '""')}"`;
  const body = rows
    .map((r) =>
      [
        esc(r.username),
        esc(r.full_name),
        esc(`https://www.instagram.com/${r.username}/`),
        r.is_verified ? "1" : "0",
        r.is_private ? "1" : "0",
      ].join(",")
    )
    .join("\n");
  return header + body;
}

function downloadBlob(filename, mime, content) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({ url, filename, saveAs: false }, () => {
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  });
}

function stampedName(prefix, username, ext) {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  return `${prefix}_${username}_${stamp}.${ext}`;
}

// --- rendering ------------------------------------------------------------

function userRow(u, suffix) {
  const li = document.createElement("li");
  const img = document.createElement("img");
  img.className = "avatar";
  if (u.profile_pic_url) img.src = u.profile_pic_url;
  img.alt = "";
  img.referrerPolicy = "no-referrer";
  const meta = document.createElement("div");
  meta.className = "user-meta";
  const a = document.createElement("a");
  a.className = "uname";
  a.href = `https://www.instagram.com/${u.username}/`;
  a.target = "_blank";
  a.rel = "noreferrer noopener";
  a.textContent = "@" + u.username;
  const fn = document.createElement("div");
  fn.className = "fname";
  fn.textContent = u.full_name || "";
  meta.appendChild(a);
  meta.appendChild(fn);
  li.appendChild(img);
  li.appendChild(meta);
  if (suffix) {
    const s = document.createElement("span");
    s.className = "when";
    s.textContent = suffix;
    li.appendChild(s);
  }
  return li;
}

function renderUserList(elId, users, emptyMsg, suffixFn) {
  const el = $(elId);
  el.innerHTML = "";
  if (!users || users.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = emptyMsg;
    el.appendChild(li);
    return;
  }
  for (const u of users) {
    el.appendChild(userRow(u, suffixFn ? suffixFn(u) : ""));
  }
}

function eventBadge(kind) {
  const span = document.createElement("span");
  span.className = "badge ";
  switch (kind) {
    case "follower_lost":
      span.classList.add("lost");
      span.textContent = "unfollowed you";
      break;
    case "follower_gained":
      span.classList.add("gained");
      span.textContent = "followed you";
      break;
    case "started_following":
      span.classList.add("followed");
      span.textContent = "you followed";
      break;
    case "stopped_following":
      span.classList.add("unfollowed");
      span.textContent = "you unfollowed";
      break;
    default:
      span.textContent = kind;
  }
  return span;
}

function renderHistory(events) {
  const el = $("listHistory");
  el.innerHTML = "";
  if (!events || events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No events yet. Run a sync to start tracking.";
    el.appendChild(li);
    return;
  }
  // Newest first, cap at 300.
  for (const ev of events.slice().reverse().slice(0, 300)) {
    const li = document.createElement("li");
    const meta = document.createElement("div");
    meta.className = "user-meta";
    const a = document.createElement("a");
    a.className = "uname";
    a.href = `https://www.instagram.com/${ev.user.username}/`;
    a.target = "_blank";
    a.rel = "noreferrer noopener";
    a.textContent = "@" + ev.user.username;
    meta.appendChild(a);
    li.appendChild(meta);
    li.appendChild(eventBadge(ev.kind));
    const when = document.createElement("span");
    when.className = "when";
    when.textContent = formatAgo(ev.ts);
    li.appendChild(when);
    el.appendChild(li);
  }
}

// --- view builders --------------------------------------------------------

function lastEventTsByUsername(events, kind) {
  const m = new Map();
  for (const ev of events) {
    if (ev.kind !== kind) continue;
    m.set(ev.user.username.toLowerCase(), ev.ts);
  }
  return m;
}

function buildViews(store) {
  const baseline = store.baseline;
  const events = store.events || [];

  // Unfollowers / New: from the events log, latest event per user wins.
  // A user can appear repeatedly (follow, unfollow, refollow) — we trust
  // current baseline membership to decide which list they currently belong in.
  const followersIdx = indexByUsername(baseline?.followers || []);
  const followingIdx = indexByUsername(baseline?.following || []);

  const lostTs = lastEventTsByUsername(events, "follower_lost");
  const gainedTs = lastEventTsByUsername(events, "follower_gained");

  // Unfollowers = users with a follower_lost event AND not currently a follower.
  const unfollowers = [];
  for (const [uname, ts] of lostTs) {
    if (followersIdx.has(uname)) continue; // they came back
    // Pick most recent matching event for user payload.
    const ev = events.slice().reverse().find((e) => e.kind === "follower_lost" && e.user.username.toLowerCase() === uname);
    if (ev) unfollowers.push({ ...ev.user, ts });
  }
  unfollowers.sort((a, b) => b.ts - a.ts);

  // New followers = users with a follower_gained event AND currently a follower.
  const newFollowers = [];
  for (const [uname, ts] of gainedTs) {
    if (!followersIdx.has(uname)) continue; // gone again
    const merged = followersIdx.get(uname);
    newFollowers.push({ ...merged, ts });
  }
  newFollowers.sort((a, b) => b.ts - a.ts);

  // Ghosts = you follow them, they don't follow you (live set diff).
  const ghosts = [];
  for (const [uname, u] of followingIdx) if (!followersIdx.has(uname)) ghosts.push(u);
  ghosts.sort((a, b) => a.username.localeCompare(b.username));

  // Fans = they follow you, you don't follow back.
  const fans = [];
  for (const [uname, u] of followersIdx) if (!followingIdx.has(uname)) fans.push(u);
  fans.sort((a, b) => a.username.localeCompare(b.username));

  return { unfollowers, newFollowers, ghosts, fans, events };
}

async function renderAll() {
  let store = await readStore();
  store = await migrateV1(store);

  const baseline = store.baseline;
  const account = store.account;
  const settings = { ...DEFAULT_SETTINGS, ...(store.settings || {}) };

  // Header / counts
  if (account?.username) {
    setStatus("ok", `Tracking @${account.username}`);
  }
  followerCount.textContent = baseline?.followers?.length?.toLocaleString() ?? "—";
  followingCount.textContent = baseline?.following?.length?.toLocaleString() ?? "—";
  lastSync.textContent = baseline?.ts ? `Last sync: ${formatAgo(baseline.ts)}` : "No sync yet.";

  // Deltas (most recent run, summed)
  const recentTs = baseline?.ts || 0;
  let fLost = 0, fGained = 0, gAdded = 0, gRemoved = 0;
  for (const ev of store.events || []) {
    if (ev.ts !== recentTs) continue;
    if (ev.kind === "follower_lost") fLost++;
    else if (ev.kind === "follower_gained") fGained++;
    else if (ev.kind === "started_following") gAdded++;
    else if (ev.kind === "stopped_following") gRemoved++;
  }
  followerDelta.textContent = recentTs ? `+${fGained} / -${fLost}` : "";
  followerDelta.className = "delta " + (fLost > fGained ? "neg" : fGained > 0 ? "pos" : "");
  followingDelta.textContent = recentTs ? `+${gAdded} / -${gRemoved}` : "";
  followingDelta.className = "delta " + (gRemoved > gAdded ? "neg" : gAdded > 0 ? "pos" : "");

  // Settings inputs
  autoSyncInterval.value = String(settings.autoSyncHours || 0);
  autoDownload.checked = !!settings.autoDownload;
  notifyUnfollow.checked = !!settings.notifyUnfollow;

  // Views
  const views = buildViews(store);
  pillUnfollowers.textContent = views.unfollowers.length;
  pillNew.textContent = views.newFollowers.length;
  pillGhosts.textContent = views.ghosts.length;
  pillFans.textContent = views.fans.length;

  renderUserList("listUnfollowers", views.unfollowers, "No unfollowers detected (need at least 2 syncs).",
    (u) => formatAgo(u.ts));
  renderUserList("listNew", views.newFollowers, "No new followers yet.",
    (u) => formatAgo(u.ts));
  renderUserList("listGhosts", views.ghosts, baseline ? "Nobody — every account you follow follows you back." : "Run a sync first.");
  renderUserList("listFans", views.fans, baseline ? "Nobody — you follow back everyone." : "Run a sync first.");
  renderHistory(views.events);

  // Stash for CSV export buttons.
  window.__lastViews = views;
}

// --- actions --------------------------------------------------------------

btnSyncNow.addEventListener("click", async () => {
  if (!currentTab || !currentUsername) return;
  // Cooperate with the background auto-sync mutex.
  const lock = await chrome.storage.local.get("_syncInFlight");
  if (lock._syncInFlight && Date.now() - lock._syncInFlight < 30 * 60 * 1000) {
    setStatus("warn", "Auto-sync is already running. Try again in a minute.");
    return;
  }
  await chrome.storage.local.set({ _syncInFlight: Date.now() });
  try {
    setBusy(true, "Collecting followers…");
    const f = await runExportOnTab(currentTab.id, "followers");
    setBusy(true, "Collecting following…");
    const g = await runExportOnTab(currentTab.id, "following");
    const settings = await getSettings();
    const result = await commitSnapshot({
      username: f.username,
      userId: f.userId,
      followers: f.users,
      following: g.users,
    });
    setBusy(false);
    if (settings.autoDownload) {
      downloadBlob(
        stampedName("instagram_snapshot", f.username, "json"),
        "application/json",
        JSON.stringify({ username: f.username, ts: Date.now(), followers: f.users, following: g.users }, null, 2)
      );
    }
    const lostN = result.followerDiff.removed.length;
    const gainedN = result.followerDiff.added.length;
    setStatus(
      "ok",
      result.priorTs
        ? `Synced. +${gainedN} / -${lostN} followers since ${formatAgo(result.priorTs)}.`
        : `First snapshot saved: ${f.users.length} followers, ${g.users.length} following.`
    );
    renderAll();
  } catch (e) {
    setBusy(false);
    setStatus("err", e.message || "Failed.");
  } finally {
    await chrome.storage.local.remove("_syncInFlight");
  }
});

btnFollowers.addEventListener("click", async () => {
  if (!currentTab || !currentUsername) return;
  try {
    setBusy(true, "Collecting followers…");
    const r = await runExportOnTab(currentTab.id, "followers");
    setBusy(false);
    downloadBlob(stampedName("instagram_followers", r.username, "csv"), "text/csv;charset=utf-8", csvForUsers(r.users));
    setStatus("ok", `Exported ${r.users.length} followers.`);
  } catch (e) {
    setBusy(false);
    setStatus("err", e.message || "Failed.");
  }
});

btnFollowing.addEventListener("click", async () => {
  if (!currentTab || !currentUsername) return;
  try {
    setBusy(true, "Collecting following…");
    const r = await runExportOnTab(currentTab.id, "following");
    setBusy(false);
    downloadBlob(stampedName("instagram_following", r.username, "csv"), "text/csv;charset=utf-8", csvForUsers(r.users));
    setStatus("ok", `Exported ${r.users.length} following.`);
  } catch (e) {
    setBusy(false);
    setStatus("err", e.message || "Failed.");
  }
});

btnOpenProfile.addEventListener("click", async () => {
  const url = currentUsername
    ? `https://www.instagram.com/${currentUsername}/`
    : "https://www.instagram.com/";
  if (currentTab) {
    chrome.tabs.update(currentTab.id, { url });
  } else {
    chrome.tabs.create({ url });
  }
});

// --- settings -------------------------------------------------------------

autoSyncInterval.addEventListener("change", async () => {
  const hours = Number(autoSyncInterval.value) || 0;
  await saveSettings({ autoSyncHours: hours });
  chrome.runtime.sendMessage({ type: "RESCHEDULE_ALARM" });
});
autoDownload.addEventListener("change", () => saveSettings({ autoDownload: autoDownload.checked }));
notifyUnfollow.addEventListener("change", () => saveSettings({ notifyUnfollow: notifyUnfollow.checked }));

// --- tabs -----------------------------------------------------------------

document.querySelectorAll(".tabs .tab").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tabs .tab").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const target = btn.dataset.tab;
    document.querySelectorAll(".tab-pane").forEach((p) => p.classList.add("hidden"));
    $("pane-" + target).classList.remove("hidden");
  });
});

document.querySelectorAll("[data-export]").forEach((btn) => {
  btn.addEventListener("click", () => {
    const key = btn.dataset.export;
    const views = window.__lastViews;
    if (!views) return;
    const map = {
      unfollowers: views.unfollowers,
      new: views.newFollowers,
      ghosts: views.ghosts,
      fans: views.fans,
    };
    const data = map[key] || [];
    if (data.length === 0) {
      setStatus("warn", `Nothing to export in "${key}".`);
      return;
    }
    const name = stampedName(`instagram_${key}`, currentUsername || "user", "csv");
    downloadBlob(name, "text/csv;charset=utf-8", csvForUsers(data));
  });
});

$("btnClearHistory").addEventListener("click", async () => {
  if (!confirm("Clear all stored history and baseline? This cannot be undone.")) return;
  await chrome.storage.local.set({ events: [], baseline: null });
  setStatus("ok", "History cleared.");
  renderAll();
});

// --- reactivity -----------------------------------------------------------

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.baseline || changes.events || changes.account || changes.settings) {
    renderAll();
  }
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "AUTOSYNC_DONE") {
    setStatus("ok", `Auto-sync finished: ${msg.summary || "ok"}`);
  } else if (msg?.type === "AUTOSYNC_FAILED") {
    setStatus("warn", `Auto-sync skipped: ${msg.reason || "unknown"}`);
  }
});

// --- init -----------------------------------------------------------------

(async () => {
  await refreshStatus();
  await renderAll();
})();
