// content.js — runs inside instagram.com pages.
// Hits Instagram's internal API with the same session cookies the page uses.
// Adds: exponential backoff on 429, resumable pagination via chrome.storage.local.

(() => {
  const IG_APP_ID = "936619743392459";
  const API_BASE = "https://www.instagram.com/api/v1";

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const jitter = (base, spread = 0.4) => base * (1 - spread / 2 + Math.random() * spread);

  async function igFetch(path, attempt = 0) {
    const res = await fetch(API_BASE + path, {
      credentials: "include",
      headers: {
        "x-ig-app-id": IG_APP_ID,
        "x-asbd-id": "129477",
        "x-requested-with": "XMLHttpRequest",
        accept: "*/*",
      },
    });
    if (res.status === 429 || res.status === 503) {
      if (attempt >= 6) {
        throw new Error(`Instagram rate-limited us (gave up after ${attempt} retries)`);
      }
      const base = Math.min(60000, 2000 * Math.pow(2, attempt));
      const wait = base + Math.random() * 1000;
      await sleep(wait);
      return igFetch(path, attempt + 1);
    }
    if (!res.ok) {
      throw new Error(`Instagram returned ${res.status} for ${path}`);
    }
    return res.json();
  }

  async function getCurrentUser() {
    try {
      const data = await igFetch("/accounts/edit/web_form_data/");
      if (data?.form_data?.username) return data.form_data.username;
    } catch (_) {}
    // Fallback 1: <link rel="alternate" href="ios-appstore://..."> or shared data
    try {
      const scripts = document.querySelectorAll('script[type="application/json"]');
      for (const s of scripts) {
        const txt = s.textContent || "";
        const m = txt.match(/"viewer"\s*:\s*\{[^}]*"username"\s*:\s*"([^"]+)"/);
        if (m) return m[1];
      }
    } catch (_) {}
    // Fallback 2: profile link in the nav.
    const navImg = document.querySelector('a[href^="/"][role="link"] img[alt*="profile picture"]');
    if (navImg) {
      const a = navImg.closest("a");
      const m = a?.getAttribute("href")?.match(/^\/([^/]+)\/$/);
      if (m) return m[1];
    }
    // Fallback 3: og:url meta if it points to a profile page.
    const meta = document.querySelector('meta[property="og:url"]');
    if (meta) {
      const m = meta.content.match(/instagram\.com\/([^/?#]+)/);
      if (m && m[1] && !["explore", "reels", "direct", "p", "stories"].includes(m[1])) {
        return m[1];
      }
    }
    return null;
  }

  async function getUserIdFromUsername(username) {
    const data = await igFetch(`/users/web_profile_info/?username=${encodeURIComponent(username)}`);
    const id = data?.data?.user?.id;
    if (!id) throw new Error("Could not resolve user ID. Are you logged in?");
    return id;
  }

  function resumeKey(userId, kind) {
    return `__scrape_state__${userId}__${kind}`;
  }

  async function loadResume(userId, kind) {
    const key = resumeKey(userId, kind);
    const got = await chrome.storage.local.get(key);
    const state = got[key];
    if (!state) return null;
    // Resume entries older than 24h are stale, drop them.
    if (Date.now() - state.savedAt > 24 * 3600 * 1000) {
      await chrome.storage.local.remove(key);
      return null;
    }
    return state;
  }

  async function saveResume(userId, kind, maxId, collected) {
    const key = resumeKey(userId, kind);
    await chrome.storage.local.set({
      [key]: {
        savedAt: Date.now(),
        maxId,
        collected: Object.fromEntries(collected),
      },
    });
  }

  async function clearResume(userId, kind) {
    await chrome.storage.local.remove(resumeKey(userId, kind));
  }

  async function scrapeList(userId, kind, onProgress) {
    const endpoint = kind === "followers" ? "followers" : "following";
    const collected = new Map();
    let maxId = null;
    let page = 0;

    const resume = await loadResume(userId, kind);
    if (resume) {
      for (const [k, v] of Object.entries(resume.collected || {})) {
        collected.set(k, v);
      }
      maxId = resume.maxId || null;
      onProgress?.(collected.size, true, true);
    }

    while (true) {
      page++;
      const qs = new URLSearchParams({ count: "50" });
      if (maxId) qs.set("max_id", maxId);
      const url = `/friendships/${userId}/${endpoint}/?${qs.toString()}`;

      let data;
      try {
        data = await igFetch(url);
      } catch (e) {
        // Save resume state and rethrow so the caller can decide.
        await saveResume(userId, kind, maxId, collected);
        throw e;
      }

      const users = data?.users || [];
      for (const u of users) {
        const key = (u.username || "").toLowerCase();
        if (!key) continue;
        if (!collected.has(key)) {
          collected.set(key, {
            username: u.username,
            full_name: u.full_name || "",
            is_private: !!u.is_private,
            is_verified: !!u.is_verified,
            pk: u.pk || u.id || null,
            profile_pic_url: u.profile_pic_url || null,
          });
        }
      }

      onProgress?.(collected.size, !!data?.next_max_id, false);

      if (!data?.next_max_id) break;
      maxId = data.next_max_id;

      // Persist resume state every few pages.
      if (page % 5 === 0) {
        await saveResume(userId, kind, maxId, collected);
      }

      await sleep(jitter(1100, 0.6));
    }

    await clearResume(userId, kind);
    return Array.from(collected.values());
  }

  // --- message handlers ---------------------------------------------------

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "PING") {
      getCurrentUser()
        .then((username) => sendResponse({ ok: true, username }))
        .catch(() => sendResponse({ ok: false }));
      return true;
    }
  });

  chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== "scrape") return;
    port.onMessage.addListener(async (msg) => {
      if (msg?.type !== "SCRAPE") return;
      try {
        const username = await getCurrentUser();
        if (!username) throw new Error("Not signed in to Instagram.");
        port.postMessage({ type: "PROGRESS", pct: 5, text: `Resolving @${username}…` });
        const userId = await getUserIdFromUsername(username);
        port.postMessage({ type: "PROGRESS", pct: 10, text: `Collecting ${msg.kind}…` });

        const users = await scrapeList(userId, msg.kind, (count, hasMore, resumed) => {
          const pct = hasMore ? Math.min(90, 10 + count / 20) : 95;
          const label = resumed ? `Resumed at ${count} ${msg.kind}…` : `Collected ${count} ${msg.kind}…`;
          port.postMessage({ type: "PROGRESS", pct, text: label });
        });

        port.postMessage({ type: "PROGRESS", pct: 100, text: "Done." });
        port.postMessage({ type: "DONE", kind: msg.kind, username, userId, users });
      } catch (e) {
        port.postMessage({ type: "ERROR", error: e?.message || String(e) });
      }
    });
  });
})();
